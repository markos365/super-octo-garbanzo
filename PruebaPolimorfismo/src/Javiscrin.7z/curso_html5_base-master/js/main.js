window.addEventListener("load", function(){
    console.log("App cargada");
})
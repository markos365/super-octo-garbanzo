$(document).ready(function(){
    console.log('Ya');

    var usuarios = {
        usuario11: {nombre: "Juan", edad: "54", imagen:'1.jpg'},
        usuario12: {nombre: "Juan2", edad: "54", imagen:'2.jpg'},
        usuario13: {nombre: "Juan3", edad: "54", imagen:'3.jpg'},
        usuario14: {nombre: "Antonio", edad: "54", imagen:'4.jpg'},
        usuario15: {nombre: "Juan4", edad: "54", imagen:'5.jpg'},
        usuario16: {nombre: "Juan5", edad: "54", imagen:'6.jpg'},
        usuario17: {nombre: "Juan6", edad: "54", imagen:'7.jpg'},
        usuario18: {nombre: "Juan7", edad: "54", imagen:'8.jpg'},
    }

    var $ul = $('#listado ul')
    pintarLista(usuarios);
    

    function pintarLista(_usuarios){
        $ul.find('.bView').each(function(){
            $(this).off('click', botonView);
        })
        $ul.find('.bDelete').each(function(){
            $(this).off('click', botonDelete);
        })
        $ul.html('');
        for (var prop in _usuarios){
            var usuario = _usuarios[prop];
            //var li = ($('<li data-id="'+prop+'"><h3>'+usuario.nombre+'</h3></li>'));
            var li = ($('<li><h3>'+usuario.nombre+'</h3></li>'));
            li.data('id', prop);
            var contenedorAmpliado = $('<div class="contenedorAmpliado"></div>');
            var edad = $('<div>'+usuario.edad+'</div>');
            var imagen = $('<img />');
            imagen.attr('src','assets/'+usuario.imagen);
            contenedorAmpliado.append(edad);
            contenedorAmpliado.append(imagen);
    
            var botonera = $('<div class="botonera"></div>')
            var bView = $('<button class="bView">View</button>')
            var bDelete = $('<button class="bDelete">Delete</button>')
            bView.on('click', botonView);
            bDelete.on('click', botonDelete);
            botonera.append(bView);
            botonera.append(bDelete);
            li.append(botonera);
            $ul.append(li);
            li.append(contenedorAmpliado);
        }

        function botonView(){
            var li =$(this).parent().parent();
            li.find('.contenedorAmpliado')
                .toggleClass('show');
        };
    
        function botonDelete(){
            var li =$(this).parent().parent();
            //$(li).remove();
            delete(_usuarios[li.data('id')]);
            pintarLista(_usuarios);
        };
    };
    $('#texto').keyup(function(){
        var texto = $(this).val();
        var filtrados = {};
        for (var prop in usuarios){
            var usuario = usuarios[prop];
            if (usuario.nombre.toLowerCase().indexOf(texto.toLowerCase()) != -1){
                filtrados[prop]=usuario;
            }      
        }
        pintarLista(filtrados);
    });

});
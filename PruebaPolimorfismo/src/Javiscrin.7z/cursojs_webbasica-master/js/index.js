$(document).ready(function(){
    var data;

    var conf = {
        method: 'GET',
        url: 'http://dev.contanimacion.com/birds/public/getBirds/1',
        dataType:'json'
    }

    $.ajax(conf)
    .done(function(response){
        data = response;
        pintaTabla;
    })
    .fail(function(error){
         console.log("Ha ocuriido un error en la llamada");
    })
    console.log('datos pedidos');

    var auxInter = 0;
    var pintaTabla = setInterval(function(){
        //for (var i = 0; i < data.length-1; i++) {
            if (auxInter < data.length-1) {
                var ul = $('#listado')
            var li =$('<li></li>')
                .data('id', data[auxInter].id)
                .on('click', detalles);
            ul.append(li.append($('<h3>'+data[auxInter].bird_name+'</h3>')));
            auxInter++;
            } else {
                clearInterval(pintaTabla);
                auxInter = 0;
            };
    }, 300)

/*    function pintaTabla(){
        for (var i = 0; i < data.length-1; i++) {
            var ul = $('#listado')
            var li =$('<li></li>')
                .data('id', data[i].id)
                .on('click', detalles);
            ul.append(li.append($('<h3>'+data[i].bird_name+'</h3>')));
        }
    };
*/
    function detalles(){
        $.ajax({
            type: "GET",
            url: "http://dev.contanimacion.com/birds/public/getBirdDetails/"+$(this).data('id'),
            dataType: "json",
            success: function (response) {
                console.log(response);
                $ventana = $('#modal')
                $ventana.empty();
                $ventana 
                    .append('<h3>'+response[0].bird_name+'</h3>')
                    .append('<img src="'+response[0].bird_image+'" />')
                    .append('<li>'+response[0].bird_description+'</li>')
                    .modal();
                
            }
        });
    };
    
    
});



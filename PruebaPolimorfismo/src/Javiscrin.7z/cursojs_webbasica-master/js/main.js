window.addEventListener("load", function(){
    //var seleccionado;
    var enlaces = document.querySelectorAll('header nav li');
    
    var urlInicial = window.location.href.toLowerCase();
    var pagina0 = urlInicial.split('/');
    var pagina = pagina0[pagina0.length - 1].split('.')[0];
    //document.querySelector('header nav li').classList.add('activo');
    for (var i = 0; i < enlaces.length; i++){
        var elemento = enlaces[i];
        if (pagina == elemento.getElementsByTagName('a')[0].innerHTML.toLowerCase()){
            elemento.classList.add('activo');
        }

        elemento.addEventListener('click', function(event){
            event.preventDefault();
            document.getElementsByTagName('h1')[0].innerHTML = this.getElementsByTagName('a')[0].innerHTML;
            document.querySelector('header nav li.activo').classList.remove('activo');
            this.classList.add('activo');
           /* if(seleccionado != undefined){
                seleccionado.classList.remove('activo');
            }
            seleccionado = this;*/
            var url = this.getElementsByTagName('a')[0].href;
            setTimeout(function(){
                window.location = url;
            }, 250)
        })
    }
    var boton_volver = document.getElementById('b_volver');
    if (boton_volver != undefined){
        boton_volver.addEventListener('click', function(){
            history.go(-1);
        })
    }
    
})

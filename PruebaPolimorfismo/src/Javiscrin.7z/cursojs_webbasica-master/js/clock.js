window.addEventListener('load',function(){
    var contenedor = document.getElementById('hora');

    function actualizarReloj(){
        var now = new Date();
        contenedor.innerHTML = formatNumber(now.getHours()) +  ':' + 
                               formatNumber(now.getMinutes()) + ':' +
                               formatNumber(now.getSeconds());
                                //+ ':' + now.getMilliseconds();
    }

    function formatNumber(value){
       /*for (var i = 0 ;i <10000000; i++){
        var tal = i * 25- 25 /1558 * 241.51 % 25;
       }*/
        if (value <10){
            return '0'+value;
        }
        return value;
    }
    setInterval(actualizarReloj, 100);

    var estado =false;
    var boton = document.getElementById('b_crono');
    var crono = document.getElementById('crono');
    var intervalo;
    boton.addEventListener('click', function(){
        var inicio = new Date();
        if (boton.innerHTML == 'Start'){
            intervalo = setInterval(cronometrar,100);
            boton.innerHTML = 'Stop';
        }else{
            boton.innerHTML = 'Start';
            clearInterval(intervalo);
            intervalo = null;
        }
        
        function cronometrar(){
            var now = new Date();
            var tal = new Date();
            tal = Math.floor ((now - inicio)/1000);
            crono.innerHTML = formato(tal);
            
        }
       
        function formato (segundos){
            //var segundos = segundoss + 3590;
            var s = segundos%60;
            var m = Math.floor((segundos/60)%60);
            var h = Math.floor(segundos/3600);
            var array = [h,m,s];

            for (var i = 0; i < 3; i++){
                if (array[i] < 10) {
                    array[i] = '0'+ array[i];
                }
            }
            var horaFormateada = array[0] + ':' +  array[1] + ':' + array[2];
            return horaFormateada;

        }
    })

    
    
})


window.addEventListener("load", function(){
  /*  var lista = [
        [1,"Juan", "54"],
        [12,"Juan", "54"],
        [13,"Juan", "54"],
        [14,"Antonio", "54"],
        [15,"Juan", "54"],
        [16,"Juan", "54"],
        [17,"Juan", "54"],
    ]
    for(var i = 0; i< lista.length; i++){
        if (lista[i][0] == 14){
            console.log(lista[i][1]);
        }
    }
*/
    var listaAsociativa = {
        usuario1: {nombre: "Juan", edad: "54"},
        usuario12: {nombre: "Juan", edad: "54"},
        usuario13: {nombre: "Juan", edad: "54"},
        usuario14: {nombre: "Antonio", edad: "54"},
        usuario15: {nombre: "Juan", edad: "54"},
        usuario16: {nombre: "Juan", edad: "54"},
        usuario17: {nombre: "Juan", edad: "54"},
        usuario18: {nombre: "Juan", edad: "54"},
    }
    console.log(listaAsociativa.usuario14.nombre);

    function recLista(){
        var contenedor = document.getElementById('usuarios');
        contenedor.innerHTML = "";
        for (var prop in listaAsociativa){
            var usuario= listaAsociativa[prop];
            crearUsuario(usuario, prop);
            
        }
    }
    recLista();

    function addTag(tag, text, parent, clase) {
        var newTag = document.createElement(tag);
        var texto = document.createTextNode(text);
        newTag.classList.add(clase);
        newTag.appendChild(texto);
        parent.appendChild(newTag);
        return newTag;
    }

    function crearUsuario(usuario,prop){
        var contenedor = document.getElementById('usuarios');
        var nuevoLi = addTag('li','', contenedor, 'fila');
        addTag('div',prop, nuevoLi, 'columna');
        addTag('div',usuario.nombre, nuevoLi, 'columna');
        addTag('div',usuario.edad, nuevoLi, 'columna');
        }
    
    document.getElementById('boton').addEventListener('click', function(){
        var nombre = document.getElementById('nombre');
        var edad = document.getElementById('edad');
        var aux = {
            nombre: nombre.value,
            edad: edad.value
        }
        var ahora = Date.now();
        listaAsociativa['usuario'+ ahora] = aux;
        console.log(listaAsociativa);
        recLista();
    })
})
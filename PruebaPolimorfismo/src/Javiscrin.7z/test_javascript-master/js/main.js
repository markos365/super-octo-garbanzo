window.addEventListener("load", function(){
    var $respuestas = $('.respuesta').addClass('hidden');
    var $preguntas = $('.pregunta');
    
       $.each($preguntas, function () { 
            $(this).click(function(){
                $respuestas.addClass('hidden');
                $(this).parent().find('.respuesta').removeClass('hidden');
            })
       }); 
});
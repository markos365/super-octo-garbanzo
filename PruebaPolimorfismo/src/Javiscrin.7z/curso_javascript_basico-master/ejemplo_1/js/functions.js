function funcionSecundaria(){
    dato = 2;
}

/*window.onload = function(){
    console.log("App cargada, onload");

}

init = function() {
    console.log("Body cargado, onload");

}
*/


crearElemento = function(etiqueta, texto, padre){
    var nuevo = document.createElement(etiqueta);
    var texto = document.createTextNode(texto);
    nuevo.appendChild(texto);
    padre.appendChild(nuevo);
}


window.addEventListener("load", function(){
    console.log("App cargada, load");
    var maincontainer = document.getElementById('main-container');

    var nav = document.getElementById('navegacion');
    var enlaces = nav.getElementsByTagName('li');

    for(var i=0; i < enlaces.length; i++){
        enlaces[i].addEventListener('click', function(){
            
            //var ul = document.getElementById('usuarios');
            var ul = document.querySelector('#main-container ul')
            crearElemento('li', this.innerHTML, ul);
            this.parentNode.removeChild(this);
        })
    }

    document.getElementById('show').addEventListener('click', function(){
        maincontainer.classList.toggle('hidden');
    })

    var contenedorUsuarios = document.getElementById('contenedor_usuarios');
    var usuarios = [{
        nombre: 'Pepe',
        edad: 58
    },{
        nombre: 'Manolo',
        edad: 546
    }

    ];
    for (var i=0; i <usuarios.length; i++){
        crearElemento('li',usuarios[i].nombre, contenedorUsuarios);
    }
})


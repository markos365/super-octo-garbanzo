fecha = new Date();
console.log(fecha.getHours() + ':'+ fecha.getMinutes() + ':' + fecha.getSeconds());

fecha2 = new Date(1962,02,25);
console.log(fecha2.getFullYear());
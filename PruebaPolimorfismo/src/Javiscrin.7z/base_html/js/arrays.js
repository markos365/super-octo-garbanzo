var array = [1, 'algo', 5];
console.log(array);

var personas =[crearPersona(11,'Juan'), crearPersona(25,'Pepe'),crearPersona(58,'Pancho'),crearPersona(998,'Luís')];
console.log(personas[2]);

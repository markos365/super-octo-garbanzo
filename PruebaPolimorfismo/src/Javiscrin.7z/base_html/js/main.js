var dato = 0;

function funcionPrimaria() {
    var dato = 1;
}



console.log(dato);
funcionPrimaria();
console.log('Dato grobal',dato);

function saluda(nombre, texto) {
    alert(texto + ': ' + nombre);
}

//saluda('jorge', 'hola');

persona = {
    edad: 35,
    nombre: 'Juan',
    nacimiento: function(){
        return 2019 - this.edad;
    }

}

var nacimiento = persona.nacimiento();
console.log(nacimiento);
persona.edad = 890;
console.log(persona.nombre + ': ' + persona.nacimiento());


function crearPersona (_edad, _nombre){
   var persona = {
        edad: _edad,
        nombre: _nombre,
        nacimiento: function(){
        return 2019 - this.edad;
        }

    }
    return persona;
}

var persona1 = crearPersona(24, 'Pepe');
console.log(persona1);

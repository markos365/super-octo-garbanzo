window.addEventListener("load", function(){
    var caja1 = new Caja(20,8845);
    var caja2 = new Caja(50,15);
    console.log(caja1);
    console.log(caja2.getArea());

    console.log(caja2.getArea());
    var bloque1 = new Bloque(120,220);
    console.log(bloque1);
    
    bloque1.render($('body'));
})

function Caja(_alto,_ancho){
    this.ancho = _ancho;
    this.alto = _alto;
}
Caja.prototype.getArea = function(){
    return this.alto * this.ancho;
}

function Bloque(_alto,_ancho){
    Caja.call(this,_alto, _ancho);
}
Bloque.prototype = Object.create(Caja.prototype);
Bloque.prototype.render = function(_tal){
    var div = $('<div></div>')
        .css("width", this.ancho)
        .css("height", this.alto)
        .css("border", '1px solid #666');
    _tal.append(div);

};

let number = 5;